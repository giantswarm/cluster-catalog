{{- define "control-plane" }}
apiVersion: controlplane.cluster.x-k8s.io/v1beta2
kind: AWSManagedControlPlane
metadata:
  annotations:
    "helm.sh/resource-policy": keep
    aws.giantswarm.io/vpc-mode: "public"
    aws.giantswarm.io/dns-mode: "public"
    aws.cluster.x-k8s.io/external-resource-gc: "true"
  labels:
    {{- include "labels.common" $ | nindent 4 }}
    app.kubernetes.io/instance: {{ .Release.Name | quote }}
    app.kubernetes.io/name: {{ .Values.global.metadata.name | default (.Release.Name | replace "." "-" | trunc 47 | trimSuffix "-") | quote }}
    app.kubernetes.io/part-of: "cluster-{{ .Values.cluster.providerIntegration.provider }}"
    app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | trunc 63 | trimSuffix "-" | trimSuffix "." }}
    giantswarm.io/service-priority: {{ .Values.global.metadata.servicePriority }}
  name: {{ include "resource.default.name" $ }}
  namespace: {{ $.Release.Namespace }}
spec:
  addons:
    {{- toYaml .Values.global.providerSpecific.addons | nindent 4 }}
  additionalTags:
    giantswarm.io/cluster: {{ include "resource.default.name" $ }}
    {{- if .Values.global.providerSpecific.additionalResourceTags -}}{{- toYaml .Values.global.providerSpecific.additionalResourceTags | nindent 4 }}{{- end}}
  associateOIDCProvider: true
  identityRef:
    kind: AWSClusterRoleIdentity
    {{- with .Values.global.providerSpecific.awsClusterRoleIdentityName }}
    name: {{ . | quote }}
    {{- end }}
  eksClusterName: {{ include "resource.default.name" $ }}
  region: {{ include "aws-region" . }}
  {{- include "secondaryCidrBlock" . | nindent 2 }}
  sshKeyName: ssh-key
  network:
    vpc:
      {{- with .Values.global.connectivity.network.vpcId }}
      id: {{ . | quote }}
      {{- end }}
      availabilityZoneUsageLimit: {{ .Values.global.connectivity.availabilityZoneUsageLimit }}
      cidrBlock: {{ .Values.global.connectivity.network.vpcCidr }}
      emptyRoutesDefaultVPCSecurityGroup: true
      {{- with .Values.global.connectivity.network.internetGatewayId }}
      internetGatewayId: {{ . | quote }}
      {{- end }}
      {{- with .Values.global.connectivity.network.vpcCidrs }}
      secondaryCidrBlocks:
        {{- toYaml . | nindent 8 }}
      {{- end }}
    subnets:
    {{- range $j, $subnet := .Values.global.connectivity.subnets }}
    {{- if $subnet.id }}
    - id: {{ $subnet.id }}
      isPublic: {{ $subnet.isPublic }}
      routeTableId: {{ $subnet.routeTableId }}
      {{- if $subnet.natGatewayId }}
      natGatewayId: {{ $subnet.natGatewayId }}
      {{- end }}
    {{- else }}
    {{- range $i, $cidr := $subnet.cidrBlocks -}}
    {{/* CAPA v2.3.0 defaults to using the `id` field as subnet name unless it's an unmanaged one (`id` starts with `subnet-`), so use CAPA's previous standard subnet naming scheme */}}
    - id: "{{ include "resource.default.name" $ }}-subnet-{{ $subnet.isPublic | default false | ternary "public" "private" }}-{{ if eq (len $cidr.availabilityZone) 1 }}{{ include "aws-region" $ }}{{ end }}{{ $cidr.availabilityZone }}"
      cidrBlock: "{{ $cidr.cidr }}"
      {{- if eq (len $cidr.availabilityZone) 1 }}
      availabilityZone: "{{ include "aws-region" $ }}{{ $cidr.availabilityZone }}"
      {{- else }}
      availabilityZone: "{{ $cidr.availabilityZone }}"
      {{- end }}
      isPublic: {{ $subnet.isPublic | default false }}
      {{- if or $subnet.tags $cidr.tags }}
      tags:
        {{- toYaml $subnet.tags | nindent 8 }}
        {{- if $cidr.tags }}
        {{- toYaml $cidr.tags | nindent 8 }}
        {{- end }}
      {{- end }}
    {{- end }}
    {{- end }}
    {{- end }}
    {{- range $j, $subnet := .Values.global.connectivity.podSubnets }}
    {{- if $subnet.id }}
    - id: {{ $subnet.id }}
      isPublic: {{ $subnet.isPublic }}
      routeTableId: {{ $subnet.routeTableId }}
      {{- if $subnet.natGatewayId }}
      natGatewayId: {{ $subnet.natGatewayId }}
      {{- end }}
    {{- else }}
    {{- range $i, $cidr := $subnet.cidrBlocks }}
    - id: "{{ include "resource.default.name" $ }}-subnet-secondary-{{ if eq (len $cidr.availabilityZone) 1 }}{{ include "aws-region" $ }}{{ end }}{{ $cidr.availabilityZone }}"
      cidrBlock: "{{ $cidr.cidr }}"
      {{- if eq (len $cidr.availabilityZone) 1 }}
      availabilityZone: "{{ include "aws-region" $ }}{{ $cidr.availabilityZone }}"
      {{- else }}
      availabilityZone: "{{ $cidr.availabilityZone }}"
      {{- end }}
      isPublic: false
      {{- if or $subnet.tags $cidr.tags }}
      tags:
        {{- if $cidr.tags }}
        {{- toYaml $cidr.tags | nindent 8 }}
        {{- end }}
      {{- end }}
    {{- end }}
    {{- end }}
    {{- end }}
  version: {{ include "cluster.component.kubernetes.version" . }}
  vpcCni:
    {{- toYaml .Values.global.providerSpecific.vpcCni | nindent 4 }}
  kubeProxy:
    {{- toYaml .Values.global.providerSpecific.kubeProxy | nindent 4 }}
  {{ if .Values.global.controlPlane.encryptionConfig.keyArn -}}
  encryptionConfig:
    provider: {{ $.Values.global.controlPlane.encryptionConfig.keyArn }}
    resources:
      {{- if and (.Values.global.controlPlane.encryptionConfig.resources) (gt (len .Values.global.controlPlane.encryptionConfig.resources) 0) }}
      {{- toYaml .Values.global.controlPlane.encryptionConfig.resources | nindent 4 }}
      {{- else }}
      - secrets
      {{- end }}
  {{- end }}
  logging:
    apiServer: {{ $.Values.global.controlPlane.logging.apiServer }}
    audit: {{ $.Values.global.controlPlane.logging.audit }}
    authenticator: {{ $.Values.global.controlPlane.logging.authenticator }}
    controllerManager: {{ $.Values.global.controlPlane.logging.controllerManager }}
  iamAuthenticatorConfig:
    mapRoles:
    - rolearn: 'arn:aws:iam::{{ include "aws-account-id" $ }}:role/GiantSwarmAdmin'
      groups:
      - "system:masters"
      username: cluster-admin
{{- if $.Values.global.controlPlane.roleMapping }}
{{- toYaml $.Values.global.controlPlane.roleMapping | nindent 4 }}
{{- end }}
  {{- if $.Values.global.controlPlane.oidc.issuerUrl }}
  oidcIdentityProviderConfig:
  {{- toYaml $.Values.global.controlPlane.oidc | nindent 4 }}
  {{- end }}
{{- end -}}
