{{/* vim: set filetype=mustache: */}}

{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimAll "-._" -}}
{{- end -}}

{{/*
Create a prefix for all resource names.
*/}}
{{- define "resource.default.name" -}}
{{- .Values.global.metadata.name | default (.Release.Name | replace "." "-" | trunc 47 | trimSuffix "-") -}}
{{- end -}}

{{- define "infrastructureApiVersion" -}}
infrastructure.cluster.x-k8s.io/v1beta2
{{- end -}}

{{/*
Common labels without kubernetes version
https://github.com/giantswarm/giantswarm/issues/22441
*/}}
{{- define "labels.selector" -}}
app: {{ include "name" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
cluster.x-k8s.io/cluster-name: {{ include "resource.default.name" . | quote }}
giantswarm.io/cluster: {{ include "resource.default.name" . | quote }}
{{- if .Values.global.metadata.organization }}
giantswarm.io/organization: {{ .Values.global.metadata.organization | quote }}
{{- end }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | quote }}
{{- end -}}

{{/*
Common labels with kubernetes version
https://github.com/giantswarm/giantswarm/issues/22441
*/}}
{{- define "labels.common" -}}
{{- include "labels.selector" . }}
app.kubernetes.io/version: {{ $.Chart.Version | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Create label to prevent accidental cluster deletion
*/}}
{{- define "preventDeletionLabel" -}}
{{- if $.Values.global.metadata.preventDeletion -}}
giantswarm.io/prevent-deletion: "true"
{{ end -}}
{{- end -}}

{{/*
Used by hook jobs.
*/}}
{{- define "securityContext.runAsUser" -}}
1000
{{- end -}}
{{- define "securityContext.runAsGroup" -}}
1000
{{- end -}}

{{/*
Converts disk size from gigabytes to bytes.
*/}}
{{- define "calculateDiskBytes" -}}
{{- mul $ 1024 1024 1024 }}
{{- end -}}

{{- define "cloudDirectorClusterAnnotations" }}
{{- if .Values.global.connectivity.dns.wildcardCnameTarget }}
{{- if regexMatch "\\." .Values.global.connectivity.dns.wildcardCnameTarget }}
{{- fail "global.connectivity.dns.wildcardCnameTarget must be a single word - no FQDNs are allowed" }}
{{- end }}
network.giantswarm.io/wildcard-cname-target: "{{ .Values.global.connectivity.dns.wildcardCnameTarget }}"
{{- end }}
{{- end }}

{{/*
Creates a list of no-proxy addresses to be rendered by giantswarm/cluster. The controlPlaneEndpointHost
will only be added if the value is populated.
*/}}
{{- define "cloudDirectorNoProxyList" }}
{{- with .Values.global.connectivity.network.loadBalancers.vipSubnet }}
- {{ . }}
{{- end }}
{{- with .Values.global.connectivity.network.controlPlaneEndpoint.host }}
- {{ . }}
{{- end }}
{{- end }}
